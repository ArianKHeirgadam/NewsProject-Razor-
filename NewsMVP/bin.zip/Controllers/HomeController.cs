﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewsMVP.Models;
using NewsMVP.MOdels;



 
 

namespace NewsMVP.Controllers
{
    public class HomeController : Controller
    {
        private readonly NewsContext _Context;
        public HomeController(NewsContext context)
        {
            _Context = context;
        }
        public async Task <IActionResult> Index()
        {
            var slidernews = await _Context.TblNews.Where(i => i.Slider == true).ToListAsync();
            var LatestNews = await _Context.TblNews.OrderByDescending(i => i.Date).Take(3).ToListAsync();
            var sidenews = await _Context.TblNews.OrderByDescending(i => i.ViewCount).Take(2).ToListAsync();
          
            var vm = new HomeViewModel
            {
               Slider = slidernews,
               Latest = LatestNews,
               Side = sidenews,
   
            };

            return View(vm);
        }
        public async Task<IActionResult> ShowAll()
        {
            var newsList = await _Context.TblNews.OrderByDescending(i => i.Date).ToListAsync();
            var comments = await _Context.TblComments.ToListAsync();

            var model = new HomeViewModel
            {
                AkharinNews = newsList,
                Comments = comments
            };

            return View(model);
        }
        public async Task<IActionResult> NewsDetail(int id)
        {
            var news = await _Context.TblNews.FirstOrDefaultAsync(n => n.Id == id);
            if (news == null) return NotFound();

            var comments = await _Context.TblComments.Where(c => c.NewsId == id && c.IsValid).OrderByDescending(c => c.Date).ToListAsync();

            var hotNews = await _Context.TblNews.OrderByDescending(n => n.ViewCount).Take(3).ToListAsync();

            var categories = await _Context.TblCategories.ToListAsync();

            var vm = new NewsDetailViewModel
            {
                News = news,
                Comments = comments,
                NewsList = hotNews,
                Categories = categories
            };

            return View(vm);
        }


        public async Task<IActionResult> ContactUs()
        {
            return View();
        }
        public async Task<IActionResult> Login()
        {
            return View();
        }
        public async Task<IActionResult> Signup()
        {
            return View();
        }
        public async Task<IActionResult> Eror404()
        {
            return View();
        }

    }

}
