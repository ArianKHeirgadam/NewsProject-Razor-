﻿

using NewsMVP.MOdels;

namespace NewsMVP.Models
{
    public class HomeViewModel
    {
        public List<TblNews> Slider { get; set; }
        public List<TblNews> Latest { get; set; }
        public List<TblNews> Side {  get; set; }
        public List<TblNews> AkharinNews{ get; set; }
        public List<TblComments> Comments { get; set; }
    }
    
}