﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewsMVP.Models;
using NewsMVP.MOdels;
using System.Linq;
using System.Threading.Tasks;

namespace NewsMVP.Utilities.ViewComponents
{
    public class MenuCategories : ViewComponent
    {
        private readonly NewsContext _context;

        public MenuCategories(NewsContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var categories = await _context.TblCategories.ToListAsync();
            return View(categories); // استفاده از Default.cshtml
        }
    }

    public class TrendingNews : ViewComponent
    {
        private readonly NewsContext _context;

        public TrendingNews(NewsContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var trending = await _context.TblNews
                .OrderByDescending(n => n.Date)
                .Take(4)
                .ToListAsync();

            return View(trending); 
        }
    }

    public class LatestNewsFooter : ViewComponent
    {
        private readonly NewsContext _context;

        public LatestNewsFooter(NewsContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var latestNews = await _context.TblNews
                .OrderByDescending(n => n.Date)
                .Take(2)
                .ToListAsync();

            return View(latestNews); 
        }
    }

    public class SocialLinks : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View(); 
        }
    }

    public class SideNewsMobile : ViewComponent
    {
        private readonly NewsContext _context;
        public SideNewsMobile(NewsContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var latestNews = await _context.TblNews.OrderByDescending(n => n.Date).FirstOrDefaultAsync();

            
            if (latestNews == null)
            {
                latestNews = new TblNews { Title = "تست ViewComponent", ImageUrlno1 = "test.jpg" };
            }

            return View(latestNews);
        }
    }

}

